{{/*
dfe-common.rollout — how a DFE app replaces its pods.

Every config change rolls the pod: one delivery mechanism for every key, so
nothing depends on which of the apps happens to watch its own config file. That
makes the ROLL the thing that has to be safe, and the default one is not --
Kubernetes allows 25% unavailable, which on a single-replica app means the old
pod is torn down before the new one is Ready and the stage is simply absent for
however long the image takes to start.

maxUnavailable 0 with maxSurge 1 inverts that: the replacement must pass its
readiness probe before the pod it replaces goes away. It costs one extra pod's
worth of headroom for the length of the roll, which is why the sizing floors
carry slack.

A workload holding a ReadWriteOnce volume CANNOT surge -- the new pod blocks
waiting for an attach the old one still holds -- so those charts keep their own
`strategy: Recreate` and do not call this.

Usage (Deployment spec, beside replicas):
  {{- include "dfe-common.rollout" . | nindent 2 }}
*/}}
{{- define "dfe-common.rollout" -}}
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 0
    maxSurge: 1
{{- end -}}
