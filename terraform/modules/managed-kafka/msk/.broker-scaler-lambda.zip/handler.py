"""Add STEP brokers to an MSK Express cluster, and never take any away.

Triggered by the scale-out alarm's SNS topic. The message body is not
read -- this always looks up the cluster's OWN current state before
acting, which is what makes a retried or duplicate SNS delivery safe.
"""
import logging
import os

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

kafka = boto3.client("kafka")


def handler(event, context):
    cluster_arn = os.environ["CLUSTER_ARN"]
    max_brokers = int(os.environ["MAX_BROKERS"])
    step = int(os.environ["STEP"])

    described = kafka.describe_cluster_v2(ClusterArn=cluster_arn)
    cluster_info = described["ClusterInfo"]
    current_version = cluster_info["CurrentVersion"]
    current_brokers = cluster_info["Provisioned"]["NumberOfBrokerNodes"]

    target_brokers = current_brokers + step

    # Increase-only, by construction: nothing below this line can ever
    # request FEWER brokers than the cluster already has.
    if target_brokers <= current_brokers:
        logger.info(
            "refusing to scale %s: step %d would not increase the broker "
            "count (currently %d)",
            cluster_arn, step, current_brokers,
        )
        return {"scaled": False, "reason": "non-positive step", "current_brokers": current_brokers}

    if target_brokers > max_brokers:
        logger.info(
            "refusing to scale %s: %d brokers would exceed max_brokers %d "
            "(currently %d)",
            cluster_arn, target_brokers, max_brokers, current_brokers,
        )
        return {"scaled": False, "reason": "at max_brokers ceiling", "current_brokers": current_brokers}

    logger.info(
        "scaling %s from %d to %d brokers (step %d, ceiling %d)",
        cluster_arn, current_brokers, target_brokers, step, max_brokers,
    )
    response = kafka.update_broker_count(
        ClusterArn=cluster_arn,
        CurrentVersion=current_version,
        TargetNumberOfBrokerNodes=target_brokers,
    )
    logger.info(
        "update_broker_count accepted: %s",
        response.get("ClusterOperationArn"),
    )
    return {"scaled": True, "from": current_brokers, "to": target_brokers}
